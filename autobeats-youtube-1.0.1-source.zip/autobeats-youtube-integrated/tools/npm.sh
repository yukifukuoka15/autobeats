#!/bin/sh
exec node "$(dirname "$0")/npm/bin/npm-cli.js" "$@"
