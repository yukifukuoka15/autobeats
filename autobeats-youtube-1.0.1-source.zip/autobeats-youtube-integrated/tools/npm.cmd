@echo off
node "%~dp0npm\bin\npm-cli.js" %*
